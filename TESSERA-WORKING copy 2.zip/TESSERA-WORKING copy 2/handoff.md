# Handoff Document – Tessera Web App

## Overview
Tessera is a **single‑file, offline HTML application** that lets music producers search Archive.org for royalty‑free audio clips, preview them with an on‑the‑fly waveform, and download the files for use in DAWs like Ableton Live.

## Key Features
- **Search UI** – text input + free‑to‑use checkbox (client‑side filter).
- **Random “Hit Me”** – fetches a fresh pool of 20 random tracks; cooldown 20 minutes. Ctrl+click during cooldown shows a humorous alert.
- **Related “Ohyhuup”** – after playing a track, searches for more items by the same creator or title keyword.
- **Waveform preview** – uses Web Audio API to decode the first few seconds and draw a simple waveform on a canvas.
- **Download button** – opens the direct audio file (MP3/OGG/WAV/FLAC) in a new tab; falls back to Archive.org item page if no playable format is found.

## File Structure (single file)
```
<tessera.html>
├─ <style> … dark Ableton‑inspired CSS
├─ <body>
│   ├─ Header (search row + Hit Me / Ohyhuup buttons)
│   ├─ Main (status, waveform canvas, results container)
│   └─ Footer (Ableton import tip)
└─ <script> – all JavaScript logic in an IIFE
```
No external libraries or build steps.

## How to Extend / Maintain
1. **Add UI elements** – Insert HTML inside the `<header>` or after the results container and reference them via `document.getElementById` at the top of the script.
2. **Change cooldown** – Modify `HIT_ME_COOLDOWN_MS` (value in ms). Remember to also update the comment if you change the intended minutes.
3. **Adjust random pool size** – In `fetchRandomPage()` edit the `rows=200` parameter; the function then slices the first 20 after shuffling.
4. **Waveform depth** – The drawing code uses the full audio buffer. For faster loads, limit the fetch to the first MB or add a range request (more advanced).
5. **Styling tweaks** – All colors are defined in CSS variables at the top; change them to match a new visual theme.

## Deployment Checklist
- [ ] Verify the file opens via `file://` on Windows/macOS browsers (Chrome/Firefox recommended).
- [ ] Test the “Hit Me” cooldown works and Ctrl+click displays the alert.
- [ ] Confirm the waveform renders for at least one MP3 sample.
- [ ] Ensure the free‑to‑use filter correctly hides non‑free licences.

## Version History (Desktop)
| File | Description |
|------|-------------|
| `tesserav1.2.html` | Initial refined version with presets removed and random features added. |
| `tesserav1.3.html` | Latest iteration after removing preset UI and cleaning up JavaScript references. |

---
*Prepared for handoff to developers or future AI assistants.*